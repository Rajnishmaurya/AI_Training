export const initialEvents = [
  {
    id: "EV101",
    title: "Intro to Cloud Computing",
    category: "Technology",
    date: "2026-11-10",
    time: "10:00",
    capacity: 4
  },

  {
    id: "EV102",
    title: "Creative Writing Lab",
    category: "Arts",
    date: "2026-11-12",
    time: "14:00",
    capacity: 3
  },

  {
    id: "EV103",
    title: "Data Visualization Basics",
    category: "Technology",
    date: "2026-11-14",
    time: "11:00",
    capacity: 5
  },

  {
    id: "EV104",
    title: "Personal Finance Essentials",
    category: "Life Skills",
    date: "2026-11-16",
    time: "16:00",
    capacity: 4
  },

  {
    id: "EV105",
    title: "Public Speaking Practice",
    category: "Life Skills",
    date: "2026-11-18",
    time: "10:30",
    capacity: 3
  },

  {
    id: "EV106",
    title: "Digital Illustration Studio",
    category: "Arts",
    date: "2026-11-20",
    time: "13:00",
    capacity: 2
  }

];